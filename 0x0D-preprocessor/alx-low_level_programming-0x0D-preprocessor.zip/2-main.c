#include <stdlib.h>
#include <stdio.h>
/**
  *main - prints name of file.
  *
  *Return: 0.
  */
int main(void)
{
	printf("%s\n", __FILE__);
	return (0);
}
