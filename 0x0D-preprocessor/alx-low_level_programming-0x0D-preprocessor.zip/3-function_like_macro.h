#ifndef ABSO
#define ABSO

#define ABS(X) (((X) < (0)) ? (-(X)) : (X))

#endif /* ABS(X) */
