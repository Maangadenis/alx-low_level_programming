#ifndef SUMM
#define SUMM

#define SUM(x, y) ((x) + (y))

#endif /* SUM */
